import torch

a = [[1,2],[1,0]]
b = [[2,1],[1,0]]
a = torch.tensor(a)
b = torch.tensor(b)
a=a.flatten()
b=b.flatten()
c = torch.dot(a,b)
print(c)
d = (c*b).sum()/(b*b).sum()
print(d)