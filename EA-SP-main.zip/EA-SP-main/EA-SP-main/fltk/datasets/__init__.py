from .cifar10 import CIFAR10Dataset
from .cifar100 import CIFAR100Dataset
from .fashion_mnist import FashionMNISTDataset
from .mnist import MNIST
