import abc


class DistNode(abc.ABC):
    """
    Distributed Learning Node abstract base classe.
    """
    pass
