from enum import Enum


class ExperimentType(Enum):
    FEDERATED = 'federated'
    DISTRIBUTED = 'distributed'
